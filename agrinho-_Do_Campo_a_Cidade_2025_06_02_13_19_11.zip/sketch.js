let stage = 0;
let skyColor, landColor, cityColor;

function setup() {
  createCanvas(600, 400);
  skyColor = color(135, 206, 235); // Cor do céu
  landColor = color(85, 107, 47); // Cor da terra
  cityColor = color(169, 169, 169); // Cor da cidade (cinza)
}

function draw() {
  background(skyColor);

  if (stage === 0) {
    // Exibir a agricultura
    drawAgriculture();
  } else if (stage === 1) {
    // Exibir a transição para a cidade
    drawTransition();
  } else if (stage === 2) {
    // Exibir a cidade
    drawCity();
  }

  // Avançar para a próxima fase após alguns segundos
  if (frameCount % 180 === 0 && stage < 2) {
    stage++;
  }
}

// Desenho da cena agrícola
function drawAgriculture() {
  // Céu
  fill(skyColor);
  noStroke();
  rect(0, 0, width, height * 0.5);

  // Terreno
  fill(landColor);
  rect(0, height * 0.5, width, height * 0.5);

  // Campos e árvores
  fill(34, 139, 34); // Cor das árvores
  ellipse(100, 300, 80, 100); // Árvore 1
  ellipse(300, 280, 100, 130); // Árvore 2
  ellipse(500, 320, 120, 140); // Árvore 3

  fill(255, 223, 0); // Cor do sol
  ellipse(80, 80, 150, 150); // Sol

  // Plantações no chão
  fill(139, 69, 19); // Cor do solo
  rect(0, height * 0.7, width, 20); // Solo

  fill(34, 139, 34); // Cor das plantas
  for (let i = 0; i < width; i += 50) {
    rect(i, height * 0.7, 30, 30); // Plantações
  }
}

// Desenho da transição para a cidade
function drawTransition() {
  // Fundo com cor cinza (começo da poluição)
  fill(cityColor);
  noStroke();
  rect(0, 0, width, height * 0.5);

  // Diminuindo a natureza
  fill(255, 255, 255, 100);
  ellipse(100, 300, 60, 80); // Árvore 1 desaparecendo
  ellipse(300, 280, 80, 110); // Árvore 2 desaparecendo
  ellipse(500, 320, 100, 120); // Árvore 3 desaparecendo

  // Introduzindo fumaça da cidade
  fill(169, 169, 169, 100); 
  ellipse(width / 2, height * 0.3, 200, 100); // Fumaça da cidade

  // Construção da cidade
  fill(100, 100, 100); // Cor dos prédios
  rect(300, height * 0.3, 50, 150); // Prédio 1
  rect(360, height * 0.25, 60, 180); // Prédio 2
  rect(430, height * 0.2, 40, 200); // Prédio 3

  // Carros e máquinas agrícolas desaparecendo
  fill(255, 0, 0);
  rect(100, height * 0.75, 40, 20); // Carro
  rect(250, height * 0.75, 40, 20); // Carro
}

// Desenho da cidade
function drawCity() {
  // Céu poluído
  fill(169, 169, 169); // Céu cinza
  noStroke();
  rect(0, 0, width, height * 0.5);

  // Terreno de concreto
  fill(105, 105, 105); // Terreno cinza
  rect(0, height * 0.5, width, height * 0.5);

  // Prédios e fumaça
  fill(100, 100, 100);
  rect(100, height * 0.2, 50, 200); // Prédio 1
  rect(200, height * 0.1, 70, 250); // Prédio 2
  rect(350, height * 0.15, 80, 230); // Prédio 3

  // Fumaça
  fill(169, 169, 169);
       }